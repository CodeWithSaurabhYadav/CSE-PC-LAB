#include<stdio.h>

int main()
{
	int a = 12, b = 25;
	printf("Output for & = %d\n", a&b);
	printf("Output for | = %d\n", a|b);
	printf("Output for ^ = %d\n", a^b);
	printf("Output for << = %d\n", a<<2);
	printf("Output for >> = %d\n", a>>2);
	return 0;
}
