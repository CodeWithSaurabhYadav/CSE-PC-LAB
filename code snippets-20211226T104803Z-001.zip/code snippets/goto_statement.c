#include<stdio.h>

int main()
{
    hello : 
        printf("hello world\n");
    goto hello;
    return 0;
}
