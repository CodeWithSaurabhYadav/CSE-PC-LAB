#include<stdio.h>

int main()
{
    /* code */
    int num1 = 5,num2 = 4,divide,multiply,add,sub;
    printf("5 / 4 = %d\n",num1/num2);
    printf("5 * 4 = %d\n",num1*num2);
    printf("5 + 4 = %d\n",num1+num2);
    printf("5 - 4 = %d\n",num1-num2);
    printf("5 % 4 = %d\n",num1%num2);
    return 0;
}
