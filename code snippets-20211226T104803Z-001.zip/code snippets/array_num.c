#include<stdio.h>

int main()
{
    /* code */
    int num[5] = {1,2,3,4,5};
    for (int i = 0; i < 5; i++)
    {
        /* code */
    }
    
    printf("%d\n",num[3]);
    return 0;
}
