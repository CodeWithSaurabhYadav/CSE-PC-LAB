#include<stdio.h>

void main()
{
    /* code */
    int num = 362;
    printf("%d\n",num+=2);
    printf("%d\n",num-=2);
    printf("%d\n",num*=2);
    printf("%d\n",num/=2);
    printf("%d\n",num&=2);
    printf("%d\n",num|=2);
    printf("%d\n",num^=2);
    printf("%d\n",num>>=2);
    printf("%d\n",num<<=2);
}
