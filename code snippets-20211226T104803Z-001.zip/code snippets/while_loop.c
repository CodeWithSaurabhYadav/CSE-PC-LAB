#include<stdio.h>

int main()
{
    int i = 20;
    do
    {
        /* code */
        printf("This is the a do while loop\n\n");
        i++;
    } while (i<5);
    int j = 20;
    while (j<25)
    {
        /* code */
        printf("This is the a while loop\n");
        j++;
    }
}